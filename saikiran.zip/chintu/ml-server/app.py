from flask import Flask, request, jsonify
from flask_cors import CORS
import joblib

app = Flask(__name__)
CORS(app)

# ✅ Load model and encodings
model = joblib.load('model.pkl')
mappings = joblib.load('mappings.pkl')

def encode_value(col, value):
    mapping = {v: k for k, v in mappings[col].items()}
    return mapping.get(value.lower(), 0)

@app.route('/predict', methods=['POST'])
def predict():
    data = request.get_json()

    disasterType = data.get('disasterType', '').lower()
    description = data.get('description', '').lower()
    damageLevel = int(data.get('damageLevel', 5))
    peopleAffected = int(data.get('peopleAffected', 0))
    needs = data.get('needs', '').lower()

    # Encode categorical values
    encoded_input = [[
        encode_value('disasterType', disasterType),
        encode_value('description', description),
        damageLevel,
        peopleAffected,
        encode_value('needs', needs)
    ]]

    # Predict severity
    pred = model.predict(encoded_input)[0]
    severity_map = {0: "Low", 1: "Medium", 2: "High"}
    severity = severity_map.get(pred, "Unknown")

    return jsonify({'severity': severity})

if __name__ == '__main__':
    app.run(port=8000)


