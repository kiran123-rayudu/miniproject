import pandas as pd
from sklearn.tree import DecisionTreeClassifier
from sklearn.model_selection import train_test_split
import joblib

# 👇 Sample dummy training data
data = pd.DataFrame([
    {"disasterType": "fire", "description": "burning forest", "damageLevel": 9, "peopleAffected": 120, "needs": "water", "severity": "High"},
    {"disasterType": "flood", "description": "overflow river", "damageLevel": 6, "peopleAffected": 60, "needs": "shelter", "severity": "Medium"},
    {"disasterType": "earthquake", "description": "minor tremor", "damageLevel": 2, "peopleAffected": 10, "needs": "none", "severity": "Low"},
    {"disasterType": "fire", "description": "smoke in area", "damageLevel": 7, "peopleAffected": 40, "needs": "medical", "severity": "Medium"},
    {"disasterType": "cyclone", "description": "strong winds", "damageLevel": 8, "peopleAffected": 90, "needs": "rescue", "severity": "High"}
])

# 👉 Convert categories to numbers
data['disasterType'] = data['disasterType'].astype('category').cat.codes
data['description'] = data['description'].astype('category').cat.codes
data['needs'] = data['needs'].astype('category').cat.codes
data['severity'] = data['severity'].map({'Low': 0, 'Medium': 1, 'High': 2})

X = data[['disasterType', 'description', 'damageLevel', 'peopleAffected', 'needs']]
y = data['severity']

# 👨‍🏫 Train model
model = DecisionTreeClassifier()
model.fit(X, y)

# 📦 Save model and category mappings
joblib.dump(model, 'model.pkl')
joblib.dump(data[['disasterType', 'description', 'needs']].astype('category').apply(lambda x: dict(enumerate(x.cat.categories))), 'mappings.pkl')

print("✅ Model trained and saved.")

