import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import ReportForm from './components/ReportForm';
import Success from './components/Success';
import AdminDashboard from './components/AdminDashboard';

function App() {
  return (
    <Router>
      <Routes>
        <Route path="/" element={<ReportForm />} />
        <Route path="/success" element={<Success />} />
        <Route path="/admin" element={<AdminDashboard />} />
      </Routes>
    </Router>
  );
}
export default App;