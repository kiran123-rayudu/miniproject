// src/components/AdminDashboard.jsx
import { useEffect, useState } from 'react';
import axios from 'axios';

function AdminDashboard() {
  const [reports, setReports] = useState([]);

  useEffect(() => {
    // Fetch all reports from backend
    const fetchReports = async () => {
      try {
        const res = await axios.get('http://localhost:5000/api/reports');
        setReports(res.data);
      } catch (error) {
        console.error('Failed to fetch reports:', error);
      }
    };

    fetchReports('http://localhost:5000/api/reports')
    .then((res) => res.json())
    .then((data) => setReports(data));
  }, []);

  return (
    <div>
      <h2>Admin Dashboard - All Disaster Reports</h2>
      {reports.length === 0 ? (
        <p>No reports submitted yet.</p>
      ) : (
        <table border="1" cellPadding="10">
          <thead>
            <tr>
              <th>ID</th>
              <th>Type</th>
              <th>Location</th>
              <th>Description</th>
              <th>Severity</th>
              <th>Resources Assigned</th>
              <th>Created At</th>
            </tr>
          </thead>
          <tbody>
            {reports.map((report) => (
              <tr key={report._id}>
                <td>{report._id}</td>
                <td>{report.disasterType}</td>
                <td>{report.location}</td>
                <td>{report.description}</td>
                <td>{report.severity || 'Pending'}</td>
                <td>{report.resourcesAssigned || 'Pending'}</td>
                <td>{new Date(report.createdAt).toLocaleString()}</td>
              </tr>
            ))}
          </tbody>
        </table>
      )}
    </div>
  );
}

export default AdminDashboard;
