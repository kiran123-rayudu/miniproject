import { useState } from 'react';
import { useNavigate } from 'react-router-dom';

function ReportForm() {
  const [formData, setFormData] = useState({
    disasterType: '',
    location: '',
    description: '',
    damageLevel: 5,
    peopleAffected: 0,
    needs: ''
  });

  const navigate = useNavigate();

  const handleChange = (e) => {
    const { name, value } = e.target;

    setFormData({
      ...formData,
      [name]: name === 'damageLevel' || name === 'peopleAffected'
        ? Number(value)
        : value
    });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    try {
      const res = await fetch('http://localhost:5000/api/reports', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(formData)
      });

      const data = await res.json();

      if (res.ok) {
        navigate('/success', { state: data });
      } else {
        alert(data.message || 'Failed to create report');
      }
    } catch (error) {
      console.error(error);
      alert('⚠️ Failed to create report');
    }
  };

  return (
    <form onSubmit={handleSubmit}>
      <h2>📋 Report a Disaster</h2>

      <label>Disaster Type:</label>
      <input
        name="disasterType"
        placeholder="e.g., flood, fire"
        value={formData.disasterType}
        onChange={handleChange}
        required
      />

      <label>Location:</label>
      <input
        name="location"
        placeholder="City or village name"
        value={formData.location}
        onChange={handleChange}
        required
      />

      <label>Description:</label>
      <textarea
        name="description"
        placeholder="Describe what happened..."
        value={formData.description}
        onChange={handleChange}
        required
      ></textarea>

      <label>Damage Level (1–10):</label>
      <input
        type="number"
        name="damageLevel"
        value={formData.damageLevel}
        onChange={handleChange}
        min="1"
        max="10"
        required
      />

      <label>People Affected:</label>
      <input
        type="number"
        name="peopleAffected"
        value={formData.peopleAffected}
        onChange={handleChange}
        min="0"
        required
      />

      <label>Urgent Needs:</label>
      <input
        name="needs"
        placeholder="e.g., food, shelter, medical"
        value={formData.needs}
        onChange={handleChange}
      />

      <br /><br />
      <button type="submit">🚨 Submit Report</button>
    </form>
  );
}

export default ReportForm;

