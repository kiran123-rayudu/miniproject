import { useLocation, useNavigate } from 'react-router-dom';
import { useEffect, useState } from 'react';

function Success() {
  const location = useLocation();
  const navigate = useNavigate();
  const reportData = location.state;

  const [report, setReport] = useState(null);

  useEffect(() => {
    if (reportData) {
      setReport(reportData);
    } else {
      // Redirect to home if no data found (e.g., user refreshed)
      navigate('/');
    }
  }, [reportData, navigate]);

  if (!report) return null;

  return (
    <div style={{ padding: '1rem' }}>
      <h2>✅ Report Submitted Successfully!</h2>
      <p><strong>Disaster Type:</strong> {report.disasterType}</p>
      <p><strong>Location:</strong> {report.location}</p>
      <p><strong>Description:</strong> {report.description}</p>
      <p><strong>Damage Level:</strong> {report.damageLevel}</p>
     <p><strong>People Affected:</strong> {report.peopleAffected}</p>
     <p><strong>Needs:</strong> {report.needs}</p>

      <p><strong>Severity:</strong> {report.severity || 'Pending ML Prediction...'}</p>
      <p><strong>Resources Assigned:</strong> {report.resourcesAssigned }</p>

      <br />
      <button onClick={() => navigate('/')}>📤 Submit Another Report</button>{' '}
      <button onClick={() => navigate('/admin')}>🗂️ Admin Dashboard</button>
    </div>
  );
}

export default Success;
