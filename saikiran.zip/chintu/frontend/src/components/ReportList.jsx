// src/components/ReportList.jsx
import { useEffect, useState } from 'react';
import axios from 'axios';

function ReportList() {
  const [reports, setReports] = useState([]);

  useEffect(() => {
    axios.get('http://localhost:5000/api/reports')
      .then((res) => setReports(res.data))
      .catch((err) => console.log(err));
  }, []);

  return (
    <div>
      <h2>All Reports</h2>
      {reports.map((report) => (
        <div key={report._id}>
          <h3>{report.disasterType}</h3>
          <p><strong>Location:</strong> {report.location}</p>
          <p>{report.description}</p>
          <hr />
        </div>
      ))}
    </div>
  );
}

export default ReportList;
